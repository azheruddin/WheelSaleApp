import { View, Text } from 'react-native'
import React from 'react'

const ShowVehicles = () => {
  return (
    <View>
      <Text>ShowVehicles</Text>
    </View>
  )
}

export default ShowVehicles