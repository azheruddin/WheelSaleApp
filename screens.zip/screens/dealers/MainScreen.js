import { View, Text } from 'react-native'
import React from 'react'

const MainScreen = () => {
  return (
    <View>
      <Text>MainScreen</Text>
    </View>
  )
}

export default MainScreen