import { View, Text } from 'react-native'
import React from 'react'

const Support = () => {
  return (
    <View>
      <Text>Support</Text>
    </View>
  )
}

export default Support