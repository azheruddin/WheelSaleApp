import { View, Text } from 'react-native'
import React from 'react'

const Account = () => {
  return (
    <View>
      <Text>Account</Text>
    </View>
  )
}

export default Account