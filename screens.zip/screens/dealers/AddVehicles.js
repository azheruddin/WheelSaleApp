import { View, Text } from 'react-native'
import React from 'react'

const AddVehicles = () => {
  return (
    <View>
      <Text>AddVehicles</Text>
    </View>
  )
}

export default AddVehicles