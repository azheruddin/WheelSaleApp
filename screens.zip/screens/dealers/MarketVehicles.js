import { View, Text } from 'react-native'
import React from 'react'

const MarketVehicles = () => {
  return (
    <View>
      <Text>MarketVehicles</Text>
    </View>
  )
}

export default MarketVehicles