import { View, Text } from 'react-native'
import React from 'react'

const SplashScreen = () => {
  return (
    <View>
      <Text>SplashScreen</Text>
    </View>
  )
}

export default SplashScreen