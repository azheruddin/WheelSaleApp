const Api = {
    api: 'http://192.168.1.28:8080/wheelsale-app-ws/dealers/',
  };
  
  export default Api;
  